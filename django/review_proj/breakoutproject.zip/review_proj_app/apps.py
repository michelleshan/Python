from django.apps import AppConfig


class ReviewProjAppConfig(AppConfig):
    name = 'review_proj_app'

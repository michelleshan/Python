from django.shortcuts import render, redirect, HttpResponse
from .models import Show

def index(request):
    context = {
        'shows': Show.objects.all()
    }
    return render(request,'index.html',context)

def add_show(request):
    return render(request,'add_show.html')

def shows_create(request):
    some_show = Show.objects.create(
        title=request.POST['title'],
        network=request.POST['network'],
        release_date=request.POST['release_date'],
        description=request.POST['description'])
    return redirect("/shows/"+str(some_show.id))

def show_info(request,id):
    context = {
        'some_show' : Show.objects.get(id=id)
    }
    return render(request,'show_info.html',context)

def edit_show(request,id):
    context = {
        'some_show2':Show.objects.get(id=id)
    }
    return render(request,'edit_show.html',context)

def shows_update(request,id):
    this_show = Show.objects.get(id=id)
    this_show.title=request.POST['title']
    this_show.network=request.POST['network']
    this_show.release_date=request.POST['release_date']
    this_show.description=request.POST['description']
    this_show.save()
    return redirect('/shows/'+str(this_show.id))

def delete_show(request,id):
    Show.objects.get(id=id).delete()
    return redirect('/shows')